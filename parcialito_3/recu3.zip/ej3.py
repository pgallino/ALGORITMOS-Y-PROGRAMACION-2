from pila import Pila

def _dfs(grafo, vertice, visitados, pila):
    visitados.add(vertice)
    for adyacente in grafo.adyacentes(vertice):
        if adyacente not in visitados:
            _dfs(grafo, adyacente, visitados, pila)
    pila.apilar(vertice)

def comunicar_empleados_topologico(grafo):
    visitados = set()
    pila = Pila()
    for vertice in grafo:
        if vertice not in visitados:
            _dfs(grafo, vertice, visitados, pila)
    return convertir_pila_a_lista(pila)

def convertir_pila_a_lista(pila):
    lista = []
    while not pila.esta_vacia():
        lista.append(pila.desapilar())
    return lista


#es el tipico algoritmo de orden topologico por lo tanto es o(v+e) ya que se trata de una variante de dfs donde visito todos 
#los vertices una vez y sus aristas.
#luego desapilar la pila para hacer la lista es lineal por lo que no cambia la complejidad.