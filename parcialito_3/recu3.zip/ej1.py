def dfs_dirigido_a_no_dirigido(grafo, vertice, visitados, grafo_extra):
    visitados.add(vertice)
    grafo_extra.agregar_vertice(vertice)
    for adyacente in grafo.adyacentes(vertice):
        if not vertice in visitados:
            dfs_dirigido_a_no_dirigido(grafo, vertice, visitados, grafo_extra):
        grafo_extra.agregar_arista(adyacente, vertice, peso = 1)

def grafo_dirigido_a_no_dirigido(grafo): #paso del grafo dirigido a uno no dirigido con dfs
    visitados = set()
    grafo_extra = Grafo(dirigido = False)
    for vertice in grafo.obtener_vertices():
        if not vertice in visitados:
            dfs_dirigido_a_no_dirigido(grafo,vertice,visitados,grafo_extra)
    return grafo_extra

def _dfs(grafo, visitados, componente, vertice):
    visitados.add(vertice)
    componente.append(vertice)
    for adyacente in grafo.adyacentes(vertice):
        if not adyacente in visitados:
            _dfs(grafo,visitados,adyacente)

def componentes_debilmente_conexas(grafo): #recolecto las componentes conexas del grafo no dirigido
    componentes = []
    visitados = set()
    for vertice in grafo.obtener_vertices():
        if not vertice in visitados:
            componente = [] #armo la sublista de la componente a recolectar
            _dfs(grafo, visitados, componente, vertice)
            componentes.append(componente) #agrago la componente a una lista de componentes
    return componentes

def componentes_debilmente_c(grafo):   #primero creo un grafo no dirigido a partir del dirigido y luego junto las conexas
    grafo_extra = grafo_dirigido_a_no_dirigido(grafo)
    return componentes_debilmente_conexas(grafo_extra)

#suponiendo que el grafo esta implementado por un diccionario de diccionarios y que agregar vertices y aristas es o(1) y que simplemente
#estoy haciendo un par de recorridos DFS (en los cuales veo cada vertice una sola vez y sus aristas)
#la complejidad total es O(v+e)
#vale aclarar que las operaciones internas son o(1) por lo que no modifican la complejidad.